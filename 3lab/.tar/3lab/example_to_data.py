#!/usr/bin/env python3
# -*- coding: utf8 -*-
import numpy as np

w = 3
h = 3

input = "A2DF4C00 F7C9FE00 9ED84500 B4E85300 99D14D00 92DD5600 A9E04C00 F7D1FA00 D4D0E900"
data = np.fromiter((int(x, 16) for x in input.split(' ')), dtype='<u4')
print(data)
print(' '.join([hex(i) for i in data]))

result = np.append([w, h], data).astype('uint32')
file = open(f'{w}x{h}.data', 'wb')
file.write(result.tobytes())
file.close()
print(f'Created {w}x{h} image')